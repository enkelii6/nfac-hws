create function increase_study_year() returns void
    language plpgsql
as
$$
BEGIN
    UPDATE students
    SET study_year = study_year + 1
    WHERE study_year < 6;
END;
$$;

alter function increase_study_year() owner to postgres;

